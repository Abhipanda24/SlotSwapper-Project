// auth context placeholder
