// auth middleware placeholder
